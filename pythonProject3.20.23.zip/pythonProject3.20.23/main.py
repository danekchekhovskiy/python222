import math
a = int(input())
b = int(input())
n = 10
h = (b - a) / n
while b >= a:
    f = math.tan(4*a + 1)
    a = a + h
    print(f)

