min_a = int(input())
max_a = int(input())
h = int(input())
print(min_a)
while min_a <= max_a:
    min_a = min_a + h
    if min_a >= max_a:
        break
    print(min_a)
  