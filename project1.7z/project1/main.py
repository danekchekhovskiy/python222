import math
#
# isGood = True
# print(isGood)
#
# isAlive = False
# print(isAlive)
#
# myAge = 16
# print('Возраст:', myAge)
#
# myCount = 76
# print('Количество:', myCount)
#
# myNumberOne = 0b11
# print(myNumberOne)    # 3 в десятичной сс
#
# myNumberTwo = 0o11
# print(myNumberTwo)    # 9 в восьмиричной сс
#
# myNumberThee = 0xA1
# print(myNumberThee)   #161 в шестнадцетиричной сс
#
# meHeight = 1.67
# pi = 3.14
# weight = 50.
# print(meHeight)
# print(pi)
# print(weight)
#
# name = "Daniil"
# Name = "Daniil"
# print(name)
# name = "Danya"
# print(name)
#
# myNumber = input()
# print(myNumber)
#
# meAge = input("Введите свой возраст")
# print("Ваш возраст", myAge)
#
#
# first_name = input("Как тебя зовут?")
# second_name = input("Какая у тебя фамилия?")
# print(first_name, second_name)

print("Индивидуальное задание №12")

a = int(input())
b = int(input())
z1  = (math.sin(a) + math.cos(2 * b - a)) / (math.cos(a) - math.sin(2 * b - a ))
print(z1)

z2 = ( 1 + math.sin(2 * b)) / (math.cos(2*b))
print(z2)

print("Задание повышенной сложности # 15")
x = int(input())
y = int(input())
e = int(input())
h = ((x**y+1 + e**y-1) / )




