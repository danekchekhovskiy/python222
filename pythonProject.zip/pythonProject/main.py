#Задание 2 самостоятельное вариант 12
import math
x = int(input("Введите значение х "))
y = int(input("Введите значение у "))
z = int(input("Введите значение z "))
c = (2**y**x) + ((3**x)**y) - (y * (math.atan(z) - (math.pi) / 6) / math.fabs(x) + 1 / y*2 + 1)
print(c)