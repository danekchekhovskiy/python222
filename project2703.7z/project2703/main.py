s = input("Введите строку")
s0 = input("Введите строку")
simvol = input("")
print(s.replace(simvol, s0))


