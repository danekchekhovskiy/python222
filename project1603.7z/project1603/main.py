import math
# a = -3
# b = 3
# h = 0.5
# while a <= b:
#     y = a * math.log(math.fabs(a - 0.6))
#     print(y)
#     a = a + h


a = int(input())
b = int(input())
h = int(input())
k = 0
summa = 0
while a <= b:
    s = (a**(2*k)) / math.factorial(2*k)
    summa = summa + s
    y = math.e**a + math.e**-a
    a = a + h
    t = math.fabs(y - summa)
    print(f"{s} значение s, {summa} сумма, {y} значение у, {t} разность y и s")


