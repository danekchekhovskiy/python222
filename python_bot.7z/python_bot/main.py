import telebot
bot = telebot.TeleBot("5859135591:AAGLKkuB5ewD_XjGhStacYwIKhXcME1SVjc")
@bot.message_handler(commands=["start"])
def start(m, res=False):
    bot.send_message(m.chat.id, 'Ванек ботаник? (Да/Нет)')
@bot.message_handler(content_types=["text"])
def handle_text(message):
    if message.text == 'Да':
        bot.send_message(message.chat.id, 'Вы как всегда правы')
    elif message.text == 'Нет':
        bot.send_message(message.chat.id, 'Вы не правы')
    else:
        bot.send_message(message.chat.id , 'Я вас не понял')

bot.polling(none_stop=True, interval=0)
