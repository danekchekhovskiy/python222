first_number = int(input("Введите первое число "))
second_number = int(input("Введите второе число "))
znak = input("Введите знак операции ")
y = 0
if znak == "+" "-" "/" "*":
    print("Знак операции верный")
elif znak == "+":
    y = first_number + second_number
    print(y)
elif znak == "-":
    y = first_number - second_number
    print(y)
elif znak == "*":
    y = first_number * second_number
    print(y)
elif znak == "/":
    if second_number == 0:
        print("На ноль делить нельзя")
    y = first_number / second_number
    print(y)
else:
    print("Знак операции неверный")




