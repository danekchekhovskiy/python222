#Задание 1
#list = [1,2,3,4,5,6,7,8,9,10]
#list.reverse()
#print(list)
#Задание 2
# list2 = [1,2,3,4,5,6,7,8,9,10]
# def change(lst):
#     lst[0], lst[-1] = lst[-1], lst[0]
# change(list2)
# print(list2)
#Задание 3

#import telebot as telega
