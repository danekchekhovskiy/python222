# Задание 2
# string = "123456789"
# print("Вывод символов при помощи положительных индексов ")
# c3 = string[2]
# print(c3)
# c5 = string[4]
# print(c5)
# c567 = string[4:7]
# print(c567)
# print("Вывод символов при помощи отрицательных индексов ")
# c23 = string[-7]
# print(c23)
# c25 = string[-5]
# print(c25)
# x = string[-5:-2]
# print(x)
#Задание 3
# string1 = "кот"
# print(string1)
# tok = string1[2] + string1[1] + string1[0]
# print(tok)
#Задание 4
# list = ["Vanek Novik", "Ivan Priymak", "Danek Novikov"]
# print(list[0], list[-1])


